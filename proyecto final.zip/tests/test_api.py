import requests


BASE_URL = "https://reqres.in/api"


def test_get_users():

    response = requests.get(f"{BASE_URL}/users?page=2")

    assert response.status_code == 200

    body = response.json()

    assert "data" in body

    assert len(body["data"]) > 0


def test_post_user():


   